this the project python for our greenhouse plc 


npm install electron --save-dev